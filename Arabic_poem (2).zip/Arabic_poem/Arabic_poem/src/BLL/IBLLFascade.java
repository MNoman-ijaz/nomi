package BLL;

import TransferObject.BookTO;
import TransferObject.RootTO;

public interface IBLLFascade extends IBookCrudBO,IRootCRUDBO {
	
	public void createBook(BookTO book);
	public void updateBook(BookTO book);
	public void deleteBook(BookTO book);
	public void readBook(BookTO book);
	public void createRoot(RootTO root);
	public void updateRoot(RootTO root);
	public void deleteRoot(RootTO root);
}
