package BLL;

import DAL.BookCrudDAO;
import DAL.DALFascade;
import TransferObject.BookTO;
import DAL.IBookCrudDAO;

public class BookCrudBO extends BLLFascade {
	
	IBookCrudDAO book1;
	IBookCrudDAO bookDAO = new BookCrudDAO(book1);
	DALFascade dataAccessFascade = new DALFascade(bookDAO); 
	
	public BookCrudBO(IBookCrudBO ibook) {
		super(ibook);
	}
	
	public void createBook(BookTO book) {
		
		if( book.getBookName().isEmpty() && book.getBookAuthor().isEmpty() && book.getYearAuthorDied().isEmpty() ) {
			// TODO
		}
		else {
			bookDAO.createBookInDB( book );
		}
	}
	
	public void updateBook(BookTO book) {
		
		if( book.getBookName().isEmpty() && book.getBookAuthor().isEmpty() && book.getYearAuthorDied().isEmpty() ) {
			// TODO
		}
		else {
			bookDAO.updateBookInDB( book );
		}
	}

	public void deleteBook(BookTO book) {
	
		if( book.getBookName().isEmpty() && book.getBookAuthor().isEmpty() && book.getYearAuthorDied().isEmpty() ) {
			// TODO
		}
		else {
			bookDAO.deleteBookInDB( book );
		}
	}
}
