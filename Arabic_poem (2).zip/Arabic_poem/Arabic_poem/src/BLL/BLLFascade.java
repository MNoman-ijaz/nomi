package BLL;

import TransferObject.BookTO;
import TransferObject.RootTO;

public class BLLFascade implements IBLLFascade {

	IBookCrudBO ibook;
	IRootCRUDBO iroot;
	
	public BLLFascade(IBookCrudBO ibook) {
		this.ibook = ibook;
	}
	public BLLFascade(IRootCRUDBO iroot) {
		this.iroot = iroot;
	}
	
	@Override
	public void createBook(BookTO book) {
		ibook.createBook(book);
	}

	@Override
	public void updateBook(BookTO book) {
		ibook.updateBook(book);
	}

	@Override
	public void deleteBook(BookTO book) {
		ibook.deleteBook(book);
	}

	@Override
	public void readBook(BookTO book) {
		ibook.readBook(book);
	}
	@Override
	public void createRoot(RootTO root) {
		iroot.createRoot(root);		
	}
	@Override
	public void updateRoot(RootTO root) {
		iroot.updateRoot(root);
		
	}
	@Override
	public void deleteRoot(RootTO root) {
		iroot.deleteRoot(root);
		
	}
}

