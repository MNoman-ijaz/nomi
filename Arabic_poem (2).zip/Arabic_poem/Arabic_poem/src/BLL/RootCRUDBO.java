package BLL;

	import DAL.RootCRUDDAO;
	import DAL.DALFascade;
	import TransferObject.RootTO;
	import DAL.IBookCrudDAO;
import DAL.IRootCRUD;



    public class RootCRUDBO  extends BLLFascade {
		
		IRootCRUD root1;
		IRootCRUD rootDAO = new RootCRUDDAO(root1);
		DALFascade dataAccessFascade = new DALFascade(rootDAO); 
		
		public RootCRUDBO(IRootCRUDBO iroot) {
			super(iroot);
		}
		
		public void  createRoot(RootTO root) {
			
			if( root.getRoot().isEmpty() ) {
				// TODO
			}
			else {
				rootDAO.createRootInDB( root );
			}
		}
public void  updateRoot(RootTO root) {
			
			if( root.getRoot().isEmpty() ) {
				// TODO
			}
			else {
				rootDAO.updateRootInDB( root );
			}
		}
		
public void  deleteRoot(RootTO root) {
	
	if( root.getRoot().isEmpty() ) {
		// TODO
	}
	else {
		rootDAO.deleteRootFromDB( root );
	}
}

}
