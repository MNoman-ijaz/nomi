package TransferObject;

public class BookTO {
	
	private String bookName, bookAuthor;
	private String yearAuthorDied = new String();
	
	public String getBookName() {
		return bookName;
	}
	
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	public String getBookAuthor() {
		return bookAuthor;
	}
	
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	
	public String getYearAuthorDied() {
		return yearAuthorDied;
	}
	
	public void setYearAuthorDied(String yearAuthorDiead) {
		this.yearAuthorDied = yearAuthorDiead;
	}
	
	
}
