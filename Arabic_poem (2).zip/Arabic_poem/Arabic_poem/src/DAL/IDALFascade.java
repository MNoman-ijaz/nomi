package DAL;

import TransferObject.BookTO;
import TransferObject.RootTO;

public interface IDALFascade extends IBookCrudDAO ,IRootCRUD{
	
	public void createBookInDB(BookTO book);
	public void updateBookInDB(BookTO book);
	public void deleteBookInDB(BookTO book);
	public void readBookInDB(BookTO book);
	public void createRootInDB(RootTO root);
	public void updateRootInDB(RootTO root);
	public void deleteRootFromDB(RootTO root);
}
