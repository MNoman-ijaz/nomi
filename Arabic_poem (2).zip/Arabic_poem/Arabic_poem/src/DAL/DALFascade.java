package DAL;

import TransferObject.BookTO;
import TransferObject.RootTO;

public class DALFascade implements IDALFascade {

	private IBookCrudDAO ibook;
	private IRootCRUD iroot;
	
	public DALFascade(IBookCrudDAO bookDAO) {
		super();
		this.ibook = bookDAO;
	}
	public DALFascade(IRootCRUD rootDAO) {
		super();
		this.iroot = rootDAO;
	}
	
	@Override
	public void createBookInDB(BookTO book) {
		ibook.createBookInDB(book);
	}

	@Override
	public void updateBookInDB(BookTO book) {
		ibook.updateBookInDB(book);
	}

	@Override
	public void deleteBookInDB(BookTO book) {
		ibook.deleteBookInDB(book);
	}

	@Override
	public void readBookInDB(BookTO book) {
		ibook.readBookInDB(book);
		
	}
	@Override
	public void createRootInDB(RootTO root) {
		
		iroot.createRootInDB(root);
	}

	@Override
	public void updateRootInDB(RootTO root) {
		iroot.updateRootInDB(root);
		
	}

	@Override
	public void deleteRootFromDB(RootTO root) {
		iroot.deleteRootFromDB(root);
		
	}
}
