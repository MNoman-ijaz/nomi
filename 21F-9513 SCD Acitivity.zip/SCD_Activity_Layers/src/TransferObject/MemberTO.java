package TransferObject;

import java.util.ArrayList;
import java.util.Date;

public class MemberTO {
	
	private int memid;
	private String name;
	private boolean is_active;
	private Date last_payment_data;
	
	ArrayList<MemberTO> mem = new ArrayList<>();
	
	public MemberTO() {
		
	}
	
	public Date getLast_payment_data() {
		return last_payment_data;
	}

	public void setLast_payment_data(Date last_payment_data) {
		this.last_payment_data = last_payment_data;
	}

	public int getMemid() {
		return memid;
	}

	public void setMemid(int memid) {
		this.memid = memid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isIs_active() {
		return is_active;
	}

	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}
}
