package PL;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import BLL.MemberBO;
import DAL.MemberDAO;
import TransferObject.MemberTO;


public class MemberPOAWT extends Frame {

	private TextArea resultArea;
	private MemberBO memBO;

	public MemberPOAWT(MemberBO _bll) {
		
		setTitle("Get Active Members");
		setSize(500, 300);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		Panel mainPanel = new Panel();
		mainPanel.setLayout(new BorderLayout());

		Panel inputPanel = new Panel();
		inputPanel.setLayout(new FlowLayout());
		
		Label lbl =  new Label("Press the Button to Get Active Members : ");
		Button getActMem = new Button("Get");

		add(lbl);
		add(getActMem);

		resultArea = new TextArea(10, 30);
		resultArea.setEditable(false);
		
		setLayout(new FlowLayout());

		add(resultArea);

		getActMem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				displayActiveMembers();
			}
		});
		
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

		add(mainPanel);
		this.memBO = _bll;
	}

	private void displayActiveMembers() {
		resultArea.setText("");
		ArrayList<MemberTO> activeMembers = memBO.getAllActiveMembers();
		if (activeMembers.isEmpty()) {
		    resultArea.append("No Active Member Available!");
		} else {
		    resultArea.append("Active Members : \n");
		    for (MemberTO member : activeMembers) {
		        resultArea.append(member.getName() + "\n");
		    }
		}
	}

	
	 public static void main(String[] args) {
		 	
	        MemberBO memberBO = new MemberBO();
	        MemberPOAWT presentationLayer = new MemberPOAWT(memberBO);

	        presentationLayer.setVisible(true);
	           
	    }
}
