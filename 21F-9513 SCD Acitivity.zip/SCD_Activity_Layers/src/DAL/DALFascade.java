package DAL;

import java.util.ArrayList;
import java.util.Map;
import TransferObject.MemberTO;

public class DALFascade implements IDALFascade {
	private IBook bookDAO;
	private IMember memberDAO;
	
	public DALFascade(IBook bookDAO, IMember memberDAO) {
		super();
		this.bookDAO = bookDAO;
		this.memberDAO = memberDAO;
	}
	
	@Override
	public ArrayList<MemberTO> getActiveMembers(){
		return memberDAO.getActiveMembers();
	}
	
	@Override
	public Map<String, Boolean> getAllBooksInSeries(String seriesName){
		return null;
	}
}
