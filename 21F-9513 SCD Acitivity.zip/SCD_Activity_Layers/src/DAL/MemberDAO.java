package DAL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import TransferObject.MemberTO;

public class MemberDAO extends DALFascade { // Corrected the class name

    private static final String DB_URL = "jdbc:mysql://localhost:3306/phpmyadmin"; // Correct the database URL
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public MemberDAO(IBook bookDAO, IMember memberDAO) {
        super(bookDAO, memberDAO);
    }

    @Override
    public ArrayList<MemberTO> getActiveMembers() {
        ArrayList<MemberTO> activeMembers = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "SELECT name FROM `members` WHERE active = 1";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String memberName = resultSet.getString("name");
                MemberTO member = new MemberTO();
                member.setName(memberName);
                activeMembers.add(member);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return activeMembers;
    }
}
