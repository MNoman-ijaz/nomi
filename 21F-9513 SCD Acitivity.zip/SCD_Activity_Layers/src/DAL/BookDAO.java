package DAL;

public class BookDAO {
	//TODO
}
