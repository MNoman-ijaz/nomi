package DAL;

import java.util.ArrayList;
import TransferObject.MemberTO;

public interface IMember {
	public ArrayList<MemberTO> getActiveMembers();
}
