package DAL;

import java.util.ArrayList;
import java.util.Map;
import TransferObject.MemberTO;

public interface IDALFascade extends IBook, IMember {
	public ArrayList<MemberTO> getActiveMembers();
	public Map<String, Boolean> getAllBooksInSeries(String seriesName);
}
