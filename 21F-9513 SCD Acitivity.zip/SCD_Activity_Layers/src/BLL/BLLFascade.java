package BLL;

import java.util.ArrayList;

import TransferObject.MemberTO;

public class BLLFascade implements IBLLFascade {
	
	private IMemberBO imemBO;
	
	public BLLFascade(IMemberBO imemBO) {
		this.imemBO = imemBO;
	}
	
	public ArrayList<MemberTO> getAllActiveMembers() {
		
		return imemBO.getAllActiveMembers(); 
	}
}
