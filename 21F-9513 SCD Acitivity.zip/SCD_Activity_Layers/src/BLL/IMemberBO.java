package BLL;

import java.util.ArrayList;
import TransferObject.MemberTO;


public interface IMemberBO {
	public ArrayList<MemberTO> getAllActiveMembers();
}
