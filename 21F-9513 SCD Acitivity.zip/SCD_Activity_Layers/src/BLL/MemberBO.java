package BLL;

import java.util.ArrayList;

import DAL.MemberDAO;
import TransferObject.MemberTO;

public class MemberBO {
	
	MemberDAO memDAO = new MemberDAO(null, null); 
	
	public ArrayList<MemberTO> getAllActiveMembers() {
		
		ArrayList<MemberTO> activeMembers = memDAO.getActiveMembers();
		return activeMembers;
	}
}
