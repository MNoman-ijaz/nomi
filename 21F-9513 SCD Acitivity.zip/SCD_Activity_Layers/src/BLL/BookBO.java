package BLL;

public class BookBO {
	// TODO
}
