package BLL;

import java.util.ArrayList;
import TransferObject.MemberTO;

public interface IBLLFascade extends IMemberBO {
	
	public ArrayList<MemberTO> getAllActiveMembers();
}
