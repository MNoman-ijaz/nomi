#include <iostream>
#include<string>
#include <fstream>
using namespace std;

// Define a structure for product details
struct Product {
	int discount = 0;
	int product_id = 0;
	string name = " ";
	double price = 0;
	string expiry_date = " ";
	Product* next;

};
Product* prear = NULL;
Product* pfront = NULL;

// Define a structure for purchase details
struct Purchase {
	int p_id = 0;
	int c_id = 0;
	double price = 0;
	Purchase* next;
};
Purchase *f;
Purchase* r;
// Define a queue for customers waiting in line
struct Customer {
	int customer_id = 0;
	string name = " ";
	Purchase* purchases = NULL;
	int num_purchases = 0;
	Customer* next = NULL;
};

Customer* front = NULL;
Customer* rear = NULL;

// Define a queue for products to be returned
struct Return {
	int customer_id;
	int product_id;
	double price;
	Return* next;
};

Return* return_front = NULL;
Return* return_rear = NULL;

// Define a queue for favorite products of each customer
struct Favorite {
	int product_id;
	Favorite* next;
};

Favorite* favorites[1000];

// Define a queue for customer complaints
struct Complaint {
	string message;
	Complaint* next;
};

Complaint* complaints_front = NULL;
Complaint* complaints_rear = NULL;

// Admin module 
void addNewProduct(int i, string n, double p, string e, int d) {
	// take product details as input and save to file

	Product* temp = new Product();
	temp->product_id = i;
	temp->name = n;
	temp->price = p;
	temp->expiry_date = e;
	temp->discount = d;
	if (pfront == NULL || prear == NULL)
	{
		pfront = prear = temp;
		temp->next = NULL;


	}
	else
	{
		temp->next = prear->next;
		prear->next = temp;
		prear = temp;
	}

	ofstream outfile;
	outfile.open("products.txt", ios::app);
	outfile << endl << temp->product_id << " " << temp->name << " " << temp->price << " " << temp->expiry_date << " " << temp->discount;
	outfile.close();
}

void displayAllProducts()
{
	// read from file and display all products
	ifstream infile;
	int p, e;
	int pr;
	string n;
	int d;
	infile.open("products.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	string str;
	while (infile.eof() == 0)
	{
		getline(infile, str);
		cout << str;
		cout << "  ";
		cout << endl;
	}
	infile.close();
}

void modifyExistingProduct() {
	displayAllProducts();
	// take product id and new details as input, read from file and modify product details
	int id;
	cout << "Enter product id: ";
	cin >> id;
	ifstream infile;
	infile.open("products.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Product p;
	bool found = false;
	ofstream outfile;
	outfile.open("temp.txt");
	while (infile >> p.product_id >> p.name >> p.price >> p.expiry_date >> p.discount) {
		if (p.product_id == id) {
			found = true;
			cout << "Enter new product name: ";
			cin >> p.name;
			cout << "Enter new product price: ";
			cin >> p.price;
			cout << "Enter new product expiry date: ";
			cin >> p.expiry_date;
		}
		outfile << p.product_id << " " << p.name << " " << p.price << " " << p.expiry_date << endl;
	}
	infile.close();
	outfile.close();
	if (!found) {
		cout << "Product not found" << endl;
		remove("temp.txt");
		return;
	}
	remove("products.txt");
	rename("temp.txt", "products.txt");
}

void deleteParticularProduct() {
	// take product id as input, read from file and delete that product 
	int id;
	cout << "Enter product id: ";
	cin >> id;
	if (pfront == NULL)
	{
		cout << "Queue is Empty";

	}
	else
	{
		Product* temp = pfront;
		pfront = pfront->next;
		delete temp;
	}
	ifstream infile;
	infile.open("products.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Product p;
	bool found = false;
	ofstream outfile;
	outfile.open("temp.txt");
	while (infile >> p.product_id >> p.name >> p.price >> p.expiry_date) {

		if (p.product_id == id) {
			found = true;
		}
		else {
			outfile << p.product_id << " " << p.name << " " << p.price << " " << p.expiry_date << endl;
		}
	}
	infile.close();
	outfile.close();
	if (!found) {
		cout << "Product not found" << endl;
		remove("temp.txt");
		return;
	}
	remove("products.txt");
	rename("temp.txt", "products.txt");
}

void customerlist()
{

	ifstream infile;
	infile.open("Customers.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Customer cust;
	string str;
	Product prod;
	while (infile.eof() == 0)
	{
		getline(infile, str);
		cout << str;
		cout << "  ";
	}
	cout << endl;

	infile.close();


}

void deletecustomer()
{
	customerlist();
	int customer_id;
	cout << "Enter customer id: ";
	cin >> customer_id;
	ifstream infile;
	infile.open("Customers.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Customer s;
	bool found = false;
	ofstream outfile;
	outfile.open("temp.txt");
	while (infile >> s.customer_id) {

		if (s.customer_id == customer_id) {
			found = true;
		}
		else {
			outfile << s.customer_id << endl;
		}
	}
	infile.close();
	outfile.close();
	if (!found) {
		cout << "Customer not found" << endl;
		remove("temp.txt");
		return;
	}
	remove("Customers.txt");
	rename("temp.txt", "Customers.txt");

}

// Customer module

void complain()
{

	ifstream out;
	   string comp1;
	out.open("complain.txt");
	cout << "Enter the complain=";
	cin.ignore();
	getline(cin, comp1);
	cout<< comp1;
	out.close();

}


void buyproduct()
{

	Customer cust;
	Purchase prod;
	ofstream outfile;
	ofstream out;
	outfile.open("Customers.txt");
	out.open("Purchases.txt");
	cout << "Enter customer name=";
	cin >> cust.name;
	displayAllProducts();
	cout << "Enter customer id=";
	cin >> cust.customer_id;
	cout << "Enter product id=";
	cin >> prod.p_id;
	Purchase* temp = new Purchase();

	temp->p_id = prod.p_id;
	temp->c_id = cust.customer_id;

	if (pfront == NULL || prear == NULL)
	{
		f = r = temp;
		temp->next = NULL;


	}
	else
	{
		temp->next = r->next;
		r->next = temp;
		r = temp;
	}

	outfile << cust.customer_id << " " << cust.name << endl;
	out << prod.p_id << " " << cust.customer_id << endl;
	outfile.close();
	out.close();

}
void buyingHistory() {
	// read customer id from input, read purchases from file and display 
	int id;
	cout << "Enter customer id:";
	cin >> id;
	ifstream infile;
	infile.open("Customers.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	string str;
	bool found = false;
	while (infile.eof() == 0)
	{
		getline(infile, str);
		cout << str;
		cout << endl;
	}

	infile.close();

}

void favoriteProducts() {
	// read customer id from input, read favorites from file and display
	int id;
	cout << "Enter customer id: ";
	cin >> id;
	Favorite* f = favorites[id];
	if (f == NULL) {
		cout << "No favorite products found for customer" << endl;
		return;
	}
	while (f != NULL) {
		cout << "Product ID: " << f->product_id << endl;
		cout << "----------------------" << endl;
		f = f->next;
	}
}

void returnOption() {
	// take product id and customer id as input, read purchase history and process return 
	int customer_id, product_id;
	cout << "Enter customer id: ";
	cin >> customer_id;
	cout << "Enter product id: ";
	cin >> product_id;
	ifstream infile;
	infile.open("Purchases.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Purchase p;
	bool found = false;
	while (infile >> p.c_id >> p.p_id) {
		if (p.c_id == customer_id && p.p_id == product_id) {
			found = true;
			Return* r = new Return;
			r->customer_id = customer_id;
			r->product_id = product_id;
			r->next = NULL;
			if (return_front == NULL) {
				return_front = r;
				return_rear = r;
			}
			else {
				return_rear->next = r;
				return_rear = r;
			}
		}
	}
	infile.close();
	if (!found) {
		cout << "No purchase found for customer and product" << endl;
	}
}

void deleteProduct() {
	// take product id as input, read from file and delete that product 
	int id;
	cout << "Enter product id=";
	cin >> id;
	if (f == NULL)
	{
		cout << "Queue is Empty";

	}
	else
	{
		Purchase* temp = f;
		f = f->next;
		delete temp;
	}
	ifstream infile;
	infile.open("Purchases.txt");
	if (!infile) {
		cout << "Error opening file" << endl;
		return;
	}
	Purchase pr;
	bool found = false;
	ofstream outfile;
	outfile.open("temp.txt");
	while (infile >> pr.p_id) {

		if (pr.p_id == id) {
			found = true;
		}
		else {
			outfile << pr.p_id << endl;
		}
	}
	infile.close();
	outfile.close();
	if (!found) {
		cout << "Product not found" << endl;
		remove("temp.txt");
		return;
	}
	remove("Purchases.txt");
	rename("temp.txt", "Purchases.txt");
}


// Exit module 
void exitNow() {
	exit(0);
}

// Admin menu
void adminMenu() {
	int choice;
	while (true) {
		cout << "1. Add new product" << endl;
		cout << "2. Display all products" << endl;
		cout << "3. Modify existing product" << endl;
		cout << "4. Delete particular product" << endl;
		cout << "5. Go back to main menu" << endl;
		cout << "6. view customer list" << endl;
		cout << "7. Delete customer" << endl;

		cin >> choice;
		switch (choice) {
		case 1:
		{
			system("cls");
			int i, d;
			string e, n;
			double p;
			cout << "Enter produc id=";
			cin >> i;
			cout << "Enter product name=";
			cin >> n;
			cout << "Enter product price=";
			cin >> p;
			cout << "Enter product expiry=";
			cin >> e;
			cout << "Enter discount=";
			cin >> d;
			addNewProduct(i, n, p, e, d);

			break;
			system("pause");
		}
		case 2:
			displayAllProducts();
			break;
		case 3:
			system("cls");
			modifyExistingProduct();
			break;
			system("pause");
		case 4:
			system("cls");
			deleteParticularProduct();
			break;
			system("pause");
		case 5:
			system("cls");
			return;
			system("pause");
		case 6:
			system("cls");
			customerlist();
			system("pause");
		case 7:
			//system("cls");
			deletecustomer();
			//	system("pause");
		}
	}
}

// Customer menu
void customerMenu() {
	int choice;
	while (true) {
		cout << "1. Buying history" << endl;
		cout << "2. Favorite products" << endl;
		cout << "3. Return a product" << endl;
		cout << "4. Go back to main menu" << endl;
		cout << "5. Buy product" << endl;
		cout << "6. Delete product" << endl;
		cout << "7. Enter complain" << endl;

		cin >> choice;
		switch (choice) {
		case 1:
			system("cls");
			buyingHistory();
			break;
			system("pause");
		case 2:
			system("cls");
			favoriteProducts();
			break;
			system("pause");
		case 3:
			system("cls");
			returnOption();
			break;
			system("pause");
		case 4:
			system("cls");
			return;
			system("pause");
		case 5:
			system("cls");
			buyproduct();
			system("pause");
		case 6:
			system("cls");
			deleteProduct();
			system("pause");
		case 7:
			system("cls");
			complain();
			system("pause");
		}
	}
}

// Main menu


int main() {
	cout << "------------------------SHOPING STORE------------------" << endl;

	int choice;
	while (true)
	 {      cout<<"Select to login As:"<<endl;
		cout << "1. Admin Module " << endl;
		cout << "2. Customer Module" << endl;
		cout << "3. Exit " << endl;
		cin >> choice;
		switch (choice) {
		case 1:
			system("cls");
			adminMenu();
			system("pause");
			break;
		case 2:
			system("cls");
			customerMenu();
			system("pause");
			break;
		case 3:

			exitNow();
			break;
		}
	}
	system("pause");
	return 0;
}

