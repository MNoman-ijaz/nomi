package dal.impl;

import java.util.ArrayList;

import dal.IMember;
import transferobjects.MemberTO;

public class MemberDAO implements IMember {

	@Override
	public ArrayList<MemberTO> getActiveMembers() {
		return null; // TODO
	}
}
