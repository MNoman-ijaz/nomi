package dal;

public interface IDALFascade extends IBook, IMember {
}
