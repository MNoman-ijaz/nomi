package bll;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dal.DatabaseHandler;

public class DataFilter {
	private DatabaseHandler dal = new DatabaseHandler();
//	private TextFileReader dal = new TextFileReader("C:\\Users\\affan\\eclipse-workspace\\MissingBookFinderLayered\\src\\dal\\book_series_with_books");
	
    public List<String> getMissingBooks(String series) {
        List<String> missingBooks = new ArrayList<>();

        Map<String, Boolean> allBooksInSeries = dal.getAllBooksInSeries(series);
        for (Map.Entry<String, Boolean> entry : allBooksInSeries.entrySet()) {
            String book = entry.getKey();
            boolean isMissing = entry.getValue();

            if (isMissing) {
            	missingBooks.add(book);
            }
        }
        return missingBooks;
    }
}
