package DAL;

public class Main {
    public static void main(String[] args) {
        PoemModel model = new PoemModel();
        Poemview view = new Poemview();
        PoemController controller = new PoemController(model, view);

        String filename = "C:\\Users\\f219513\\Downloads\\Poem.txt";
        controller.parsePoem(filename);
    }
}

