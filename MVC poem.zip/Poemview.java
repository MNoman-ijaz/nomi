package DAL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Poemview {
    private JFrame frame;
    private JTable jTable;

    public Poemview() {
        frame = new JFrame("Poem Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jTable = new JTable();
        frame.getContentPane().add(new JScrollPane(jTable));
        frame.pack();
        frame.setVisible(true);
    }

    public void setTableModel(DefaultTableModel model) {
        jTable.setModel(model);
    }
}
