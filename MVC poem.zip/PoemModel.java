package DAL;
import java.util.ArrayList;
import java.util.List;

public class PoemModel {
    private List<Object[]> tableData;

    public PoemModel() {
        tableData = new ArrayList<>();
    }

    public void parsePoem(String filename) {
        // Move the code for parsing the poem from the main method here
        // Initialize tableData as needed
    }

    public List<Object[]> getTableData() {
        return tableData;
    }
}
