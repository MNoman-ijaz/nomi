package DAL;

public class PoemController {
    private PoemModel model;
    private Poemview view;

    public PoemController(PoemModel model, Poemview view) {
        this.model = model;
        this.view = view;
    }

    public void parsePoem(String filename) {
        model.parsePoem(filename);
        DefaultTableModel tableModel = new DefaultTableModel(
                model.getTableData().toArray(new Object[0][]),
                new String[]{"Column 1", "Column 2"}
        );
        view.setTableModel(tableModel);
    }
}

